package com.fooddelivery.controllers;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.fooddelivery.models.DeliveryAgent;
import com.fooddelivery.services.DeliveryAgentService;

@RestController
@CrossOrigin(origins="http://localhost:4200")

public class DeliveryAgentController {
		@Autowired
	    private DeliveryAgentService delagentService;

	    //gets all delivery agents
	    @GetMapping("/showallAgents")
	    public List<DeliveryAgent> getAllAgents() {
	        return delagentService.getAllAgents();
	    }

	    //gets delivery agent id
	    @GetMapping("/showAgent/{agentid}")
	    public DeliveryAgent getAgentById(@PathVariable int agentid) {
	        return delagentService.getAgentById(agentid);
	    }

	    //adds new delivery agent
	    @PostMapping("/addAgent")
	    public DeliveryAgent saveAgent(@RequestBody DeliveryAgent agent) {
	        return delagentService.saveAgent(agent);
	    }

	}


