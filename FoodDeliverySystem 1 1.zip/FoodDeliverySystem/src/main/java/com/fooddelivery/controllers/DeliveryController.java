package com.fooddelivery.controllers;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.fooddelivery.models.Delivery;
import com.fooddelivery.services.DeliveryService;

@RestController
@CrossOrigin(origins="http://localhost:4200")

public class DeliveryController {
		 @Autowired
		  private DeliveryService deliveryService;
		  
		  
		  //creates new delivery
		  @PostMapping("/createnewDelivery")
		  public Delivery createDelivery(@RequestBody Delivery delivery) {
    	  //System.out.println("Recieved data " + delivery);
			  return deliveryService.createDelivery(delivery);
		  }
		  
		  
		  //assigns delivery agent to a delivery
		  @PutMapping("/assign/{deliveryId}/agent/{agentId}")
		  public Delivery assignAgent(@PathVariable int deliveryId, @PathVariable int agentId) {
		      return deliveryService.assignAgent(deliveryId, agentId);
		  }

		  
		 //updates the status of a delivery(like- Delivered or In Progress)
	   @PutMapping("/status/{deliveryId}")
	   public Delivery updateDeliveryStatus(@PathVariable int deliveryId, @RequestParam String status){
	       return deliveryService.updateStatus(deliveryId, status);
	   }

	   
	   //gets delivery id
	   @GetMapping("/getDelivery/{deliveryid}")
	   public Delivery getDeliveryById(@PathVariable int deliveryid){
	       return deliveryService.getDeliveryById(deliveryid);
	   }
	}

