package com.fooddelivery.controllers;


import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.http.HttpStatus;

import org.springframework.http.ResponseEntity;

import org.springframework.web.bind.annotation.CrossOrigin;

import org.springframework.web.bind.annotation.GetMapping;

import org.springframework.web.bind.annotation.PathVariable;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;
 
import com.fooddelivery.models.Member;

import com.fooddelivery.services.MemberService;
 
//import io.swagger.v3.oas.annotations.parameters.RequestBody;


@RestController

@CrossOrigin(origins="http://localhost:4200")

@RequestMapping("/members")
public class MemberController {
		@Autowired 

		MemberService memberService;
	 
		@PostMapping("/insertMember")

		public String insertMember(@RequestBody Member obj){

			memberService.insertMember(obj);

			return "Inserted Successfully";

		}
	 
		@GetMapping("/login/{email}/{pwd}")

		public ResponseEntity<String> login(@PathVariable String email, @PathVariable String pwd) {

		    String result = memberService.validateUserByEmail(email, pwd);

		    if ("Valid User".equals(result)) {

		        return ResponseEntity.ok(result);

		    } else {

		        return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(result); // 401

		    }

		}

	}

