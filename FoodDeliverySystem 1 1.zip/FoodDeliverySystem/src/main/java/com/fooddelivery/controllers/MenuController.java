package com.fooddelivery.controllers;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.fooddelivery.models.Menu;
import com.fooddelivery.services.MenuService;

@RestController
@CrossOrigin(origins="http://localhost:4200")

public class MenuController {
		@Autowired
		MenuService menuService;
		
		//http://localhost:8080/restaurants/{restaurantId}/addMenu
		@PostMapping("/restaurants/{restaurantId}/addMenu")
		public Menu addMenu(@PathVariable int restaurantId,@RequestBody Menu menu) {
			return menuService.addMenu(restaurantId, menu);
		}
		
		//http://localhost:8080/restaurants/updateMenu/{itemId}
		@PutMapping("/restaurants/{restaurantId}/updateMenu/{itemId}")
		public Menu updateMenu(@PathVariable int restaurantId, @PathVariable int itemId, @RequestBody Menu menu) {
			return menuService.updateMenu(restaurantId, itemId, menu);
		}
		
		//http://localhost:8080/restaurants/111/deleteMenu/2
		@DeleteMapping("/restaurants/{restaurantId}/deleteMenu/{itemId}")
		public String deleteMenu(@PathVariable int restaurantId, @PathVariable int itemId) {
			return menuService.deleteMenu(itemId);
		}
		
		//http://localhost:8080/restaurants/{restaurantId}/getAllMenu
		@GetMapping("/restaurants/getAllMenu")
		public List<Menu> getAllMenu(){
			return menuService.getAllMenu();
		}
	}


