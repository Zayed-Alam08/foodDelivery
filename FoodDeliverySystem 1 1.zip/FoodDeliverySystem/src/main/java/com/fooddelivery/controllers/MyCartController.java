package com.fooddelivery.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.fooddelivery.models.MyCart;
import com.fooddelivery.services.MyCartService;

@RestController
@CrossOrigin(origins="http://localhost:4200")
public class MyCartController {
		
			@Autowired
			MyCartService mycartService;
			
			@PostMapping("/addToMyCart")
			public MyCart insertItem(@RequestBody MyCart mycartObj) {
				System.out.println("Inside controller "+mycartObj);
				return mycartService.insertItem(mycartObj);
			}
			
			@DeleteMapping("/deleteItem/{itemId}")
			public void delOrd(@PathVariable int itemId){
				mycartService.deleteItem(itemId);
			}
			
			@GetMapping("/getMyCartItems")
			public List<MyCart> getCartItem(){
				return mycartService.getMyCartItem();
			}
			
			@PutMapping("/changeQuantity/{itemId}/{quantity}")
			public void changeQuantity(@PathVariable int itemId,@PathVariable int quantity){
				mycartService.changeQuantity(itemId,quantity);
			}
			
//			@PutMapping("/updateOrderId/{orderId}")
//			public void updateOrderId(@PathVariable int orderId) {
//				mycartService.updateOrderId(orderId);
//				return;
//			}
	
}
