package com.fooddelivery.controllers;
 
import java.util.List;
 
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.web.bind.annotation.CrossOrigin;

import org.springframework.web.bind.annotation.GetMapping;

import org.springframework.web.bind.annotation.PostMapping;

import org.springframework.web.bind.annotation.RequestBody;

import org.springframework.web.bind.annotation.RestController;
 
import com.fooddelivery.models.Order;

import com.fooddelivery.services.OrderService;
 
@RestController

@CrossOrigin(origins="http://localhost:4200")

public class OrderController {
 
@Autowired

OrderService orderser;
 
@PostMapping("/inOrd")

public Order insertItem(@RequestBody Order orderObj) {

     System.out.println("Inside controller " + orderObj);

     return orderser.save(orderObj);

}
 
@GetMapping("/getOrd")

public List<Order> getAllItems() {

     return orderser.getAllItems();

}
 
}

 