package com.fooddelivery.controllers;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fooddelivery.models.Payment;
import com.fooddelivery.services.PaymentService;

@RestController
@CrossOrigin(origins="http://localhost:4200")

@RequestMapping("/payment")

public class PaymentController {
		@Autowired
		private PaymentService paymentService;
		
		@PostMapping("/process")
		public Payment processPayment(@RequestBody Payment payment) {
			return paymentService.processPayment(payment);
		}
		
		@GetMapping("/status/{transactionId}")
		public Payment getStatus(@PathVariable String transactionId) {
			return paymentService.getPaymentStatus(transactionId);
		}
		
		@PostMapping("/refund/{transactionId}")
		public Payment refund(@PathVariable String transactionId) {
			return paymentService.refundPayment(transactionId);
		}
		
		@PostMapping("/confirmation/{transactionId}")
		public String confirm(@PathVariable String transactionId) {
			return paymentService.sendConfirmation(transactionId);
		}
	}

