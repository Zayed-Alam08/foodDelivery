package com.fooddelivery.controllers;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fooddelivery.models.Restaurant;
import com.fooddelivery.services.RestaurantService;

@RestController
@CrossOrigin(origins="http://localhost:4200")

public class RestaurantController {
		@Autowired
		private RestaurantService restaurantService;
		
		//http://restaurants/getAllRestaurants
		@GetMapping("/restaurants/getAllRestaurants")
		public List<Restaurant> getAllRestaurants(){
			return restaurantService.getAllRestaurants();
		}
	}

