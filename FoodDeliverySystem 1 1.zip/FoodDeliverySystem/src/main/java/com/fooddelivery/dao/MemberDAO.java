package com.fooddelivery.dao;


import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Repository;

import com.fooddelivery.models.Member;

import com.fooddelivery.repositories.MemberRepository;

@Repository
public class MemberDAO {
	 
		@Autowired

		MemberRepository memberRepo;

		public String insertMember(Member obj) {

			memberRepo.save(obj);

			return "Inserted Successfully";// save() handles both insert and update

		}

		public Optional<Member> findByEmailAndPassword(String email, String password) {

		    return memberRepo.findByEmailAndPassword(email, password);

	    }

	}

