package com.fooddelivery.dao;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.fooddelivery.models.Order;
import com.fooddelivery.repositories.OrderRepository;

@Repository
public class OrderDAO {
	 @Autowired
	
	 public OrderRepository orderrepo;
	
		public Order save(Order orderObj) {
			return orderrepo.save(orderObj);
			
		}
		
		public List<Order> getAllItems(){
			return orderrepo.findAll();
		}
//		
//		public String deleteById(int id){
//			orderrepo.deleteById(id);
//			return null;
//		}
}