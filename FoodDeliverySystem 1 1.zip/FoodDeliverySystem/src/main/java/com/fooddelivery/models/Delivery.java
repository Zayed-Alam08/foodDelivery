package com.fooddelivery.models;

import java.time.LocalDateTime;


import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;

@Entity
public class Delivery {
		@Id
	    private int deliveryId;
	    private String orderId;
	    private String deliverystatus;
	    private LocalDateTime estimatedTimeOfArrival;

	    @ManyToOne
	    @JoinColumn(name= "agent_id")
	    private DeliveryAgent agent;
	    
	    public Delivery() {}

		public Delivery(int deliveryId, String orderId, String deliverystatus, LocalDateTime estimatedTimeOfArrival,
				DeliveryAgent agent) {
			this.deliveryId= deliveryId;
			this.orderId= orderId;
			this.deliverystatus= deliverystatus;
			this.estimatedTimeOfArrival= estimatedTimeOfArrival;
			this.agent = agent;
		}

		public int getDeliveryId() {
			return deliveryId;
		}

		public void setDeliveryId(int deliveryId) {
			this.deliveryId = deliveryId;
		}

		public String getOrderId() {
			return orderId;
		}

		public void setOrderId(String orderId) {
			this.orderId = orderId;
		}

		public LocalDateTime getEstimatedTimeOfArrival() {
			return estimatedTimeOfArrival;
		}

		public String getDeliverystatus() {
			return deliverystatus;
		}

		public void setDeliverystatus(String deliverystatus) {
			this.deliverystatus = deliverystatus;
		}

		public void setEstimatedTimeOfArrival(LocalDateTime estimatedTimeOfArrival) {
			this.estimatedTimeOfArrival = estimatedTimeOfArrival;
		}

		public DeliveryAgent getAgent() {
			return agent;
		}

		public void setAgent(DeliveryAgent agent) {
			this.agent = agent;
		}

		@Override
		public String toString() {
			return "Delivery [deliveryId=" + deliveryId + ", orderId=" + orderId + ", deliverystatus=" + deliverystatus
					+ ", estimatedTimeOfArrival=" + estimatedTimeOfArrival + ", agent=" + agent + "]";
		}
		
		
	}


