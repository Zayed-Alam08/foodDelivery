package com.fooddelivery.models;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class DeliveryAgent {
	
		@Id
	    private int agentId;
	    private String name;
	    private String contact;
	    
	    public DeliveryAgent() {}
	    
		public DeliveryAgent(int agentId, String name, String contact) {
			this.agentId = agentId;
			this.name = name;
			this.contact = contact;
		}

		public int getAgentId() {
			return agentId;
		}

		public void setAgentId(int agentId) {
			this.agentId = agentId;
		}

		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}

		public String getContact() {
			return contact;
		}

		public void setContact(String contact) {
			this.contact = contact;
		}

		@Override
		public String toString() {
			return "DeliveryAgent [agentId=" + agentId + ", name=" + name + ", contact=" + contact + "]";
		}
		
		
	}

