package com.fooddelivery.models;
import jakarta.persistence.Entity;

import jakarta.persistence.Id;

import jakarta.persistence.Table;

@Entity 

@Table(name = "Member") 
public class Member {
		@Id 

		private int memberId;

		private String name;

		private String email;

		private String phone;

		private String address;

		private String password;
	 
		public Member() {}

		public Member(int memberId, String name, String email, String phone, String address, String password) {

			super();

			this.memberId = memberId;

			this.name = name;

			this.email = email;

			this.phone = phone;

			this.address = address;

			this.password = password;

		}

		public int getMemberId() {

			return memberId;

		}

		public void setMemberId(int memberId) {

			this.memberId = memberId;

		}

		public String getName() {

			return name;

		}

		public void setName(String name) {

			this.name = name;

		}

		public String getEmail() {

			return email;

		}

		public void setEmail(String email) {

			this.email = email;

		}

		public String getPhone() {

			return phone;

		}

		public void setPhone(String phone) {

			this.phone = phone;

		}

		public String getAddress() {

			return address;

		}

		public void setAddress(String address) {

			this.address = address;

		}

		public String getPassword() {

			return password;

		}

		public void setPassword(String password) {

			this.password = password;

		}

		@Override

		public String toString() {

			return "Member [memberId=" + memberId + ", name=" + name + ", email=" + email + ", phone=" + phone

					+ ", address=" + address + ", password=" + password + "]";

		}

	}

