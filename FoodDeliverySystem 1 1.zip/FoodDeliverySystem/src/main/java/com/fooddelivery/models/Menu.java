package com.fooddelivery.models;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "menu")
public class Menu {
		@Id
		@GeneratedValue(strategy = GenerationType.IDENTITY)
		@Column(name = "itemId") 
		private int itemId;
		@Column(name = "itemName")
		private String itemName;
		@Column(name = "price")
		private int price;
		@ManyToOne
		@JoinColumn(name = "restaurantId", nullable = false)
		Restaurant restaurant;
		Menu(){}
		public Menu(int itemId, String itemName, int price, Restaurant restaurant){
			super();
			this.itemId = itemId;
			this.itemName = itemName;
			this.price = price;
			this.restaurant = restaurant;
		}
	 
		public int getItemId() {
			return itemId;
		}
	 
		public void setItemId(int itemId) {
			this.itemId = itemId;
		}
	 
		public String getItemName() {
			return itemName;
		}
	 
		public void setItemName(String itemName) {
			this.itemName = itemName;
		}
	 
		public int getPrice() {
			return price;
		}
	 
		public void setPrice(int price) {
			this.price = price;
		}
	 
		public Restaurant getRestaurant() {
			return restaurant;
		}
	 
		public void setRestaurant(Restaurant restaurant) {
			this.restaurant = restaurant;
		}
		@Override
		public String toString() {
			return "Menu [itemId=" + itemId + ", itemName=" + itemName + ", price=" + price + ", restaurant="
					+ restaurant + "]";
		}
		
		
	}

