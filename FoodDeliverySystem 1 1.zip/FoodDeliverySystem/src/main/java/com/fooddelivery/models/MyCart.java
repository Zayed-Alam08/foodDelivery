package com.fooddelivery.models;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="MyCart")
public class MyCart {
		@Id
		private int itemId;
		private String itemName;
		private int quantity;
		private String orderId;
		private int price;
		
		
		
		public MyCart() {
//			super();
		}
		public MyCart(int itemId, int quantity, String orderId, String itemName,int price) {
			super();
			this.itemId = itemId;
			this.quantity = quantity;
			this.orderId = orderId;
			this.itemName = itemName;
			this.price=price;
		}
		public int getItemId() {
			return itemId;
		}
		public void setItemId(int itemId) {
			this.itemId = itemId;
		}
		public int getQuantity() {
			return quantity;
		}
		public void setQuantity(int quantity) {
			this.quantity = quantity;
		}
		public String getOrderId() {
			return orderId;
		}
		public void setOrderId(String orderId) {
			this.orderId = orderId;
		}
		
		
		public String getItemName() {
			return itemName;
		}
		public void setItemName(String itemName) {
			this.itemName = itemName;
		}
		
		public int getPrice() {
			return price;
		}
		public void setPrice(int price) {
			this.price = price;
		}
		@Override
		public String toString() {
			return "MyCart [itemId=" + itemId + ", itemName=" + itemName + ", quantity=" + quantity + ", orderId="
					+ orderId + ", price=" + price + "]";
		}
		
		
		
		
		
		
		
}
