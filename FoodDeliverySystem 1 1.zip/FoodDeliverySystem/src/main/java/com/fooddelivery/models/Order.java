package com.fooddelivery.models;

import java.time.LocalDateTime;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table; 
@Entity

@Table(name = "Orders")

public class Order {
 
@Id

private String orderId;

private int customerId;

private LocalDateTime orderDate;

private String orderStatus;

private double amount;
 


public Order() {

	super();

}
 
public Order(String orderId, int customerId, LocalDateTime orderDate, String orderStatus, double amount) {

	super();

	this.orderId = orderId;

	this.customerId = customerId;

	this.orderDate = orderDate;

	this.orderStatus = orderStatus;

	this.amount = amount;

}
 
public double getAmount() {

     return amount;

}
 
public void setAmount(double amount) {

     this.amount = amount;

}
 
public String getOrderId() {

     return orderId;

}
 
public void setOrderId(String orderId) {

     this.orderId = orderId;

}
 
public int getCustomerId() {

     return customerId;

}
 
public void setCustomerId(int customerId) {

     this.customerId = customerId;

}
 
public LocalDateTime getOrderDate() {

     return orderDate;

}
 
public void setOrderDate(LocalDateTime orderDate) {

     this.orderDate = orderDate;

}
 
public String getOrderStatus() {

     return orderStatus;

}
 
public void setOrderStatus(String orderStatus) {

     this.orderStatus = orderStatus;

}
 
@Override

public String toString() {

	return "Order [orderId=" + orderId + ", customerId=" + customerId + ", orderDate=" + orderDate + ", orderStatus="

			+ orderStatus + ", amount=" + amount + "]";

}

}

 