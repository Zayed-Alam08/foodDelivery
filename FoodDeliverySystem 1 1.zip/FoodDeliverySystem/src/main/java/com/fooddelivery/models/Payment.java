package com.fooddelivery.models;

import java.time.LocalDateTime;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="Payments")
public class Payment {
	
		@Id
		private String transactionId;
		private int userId;
		private String orderId;
		private double amount;
		private String methodOfPayment;
		private String paymentstatus;
		private LocalDateTime timestamp;

		public Payment() {
//			super();
		}
		
		public Payment(String transactionId, int userId, String orderId, double amount, String methodOfPayment,
				String paymentstatus, LocalDateTime timestamp) {
			super();
			this.transactionId = transactionId;
			this.userId = userId;
			this.orderId = orderId;
			this.amount = amount;
			this.methodOfPayment = methodOfPayment;
			this.paymentstatus = paymentstatus;
			this.timestamp = timestamp;
		}


		public String getMethodOfPayment() {
			return methodOfPayment;
		}
		public void setMethodOfPayment(String methodOfPayment) {
			this.methodOfPayment = methodOfPayment;
		}
		public int getUserId() {
			return userId;
		}
		public void setUserId(int userId) {
			this.userId = userId;
		}
		public String getTransactionId() {
			return transactionId;
		}
		public void setTransactionId(String transactionId) {
			this.transactionId = transactionId;
		}
		public String getOrderId() {
			return orderId;
		}
		public void setOrderId(String orderId) {
			this.orderId = orderId;
		}
		public Double getAmount() {
			return amount;
		}
		public void setAmount(Double amount) {
			this.amount = amount;
		}
		
		public String getPaymentstatus() {
				return paymentstatus;
		}
		public void setPaymentstatus(String paymentstatus) {
				this.paymentstatus = paymentstatus;
		}
		public LocalDateTime getTimestamp() {
			return timestamp;
		}
		public void setTimestamp(LocalDateTime timestamp) {
			this.timestamp = timestamp;
		}

		@Override
		public String toString() {
			return "Payment [transactionId=" + transactionId + ", userId=" + userId + ", orderId=" + orderId
					+ ", amount=" + amount + ", methodOfPayment=" + methodOfPayment + ", paymentstatus=" + paymentstatus
					+ ", timestamp=" + timestamp + "]";
		}
	
	}


