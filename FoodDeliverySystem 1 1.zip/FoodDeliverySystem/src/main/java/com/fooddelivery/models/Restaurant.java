package com.fooddelivery.models;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "restaurant")
public class Restaurant {

		@Id
		@Column(name = "restaurantId")
		private int restaurantId;
		@Column(name = "restaurantName")
		private String restaurantName;
		
		Restaurant(){}
	 
		public Restaurant(int restaurantId, String restaurantName) {
			super();
			this.restaurantId = restaurantId;
			this.restaurantName = restaurantName;
		}
	 
		public int getRestaurantId() {
			return restaurantId;
		}
	 
		public void setRestaurantId(int restaurantId) {
			this.restaurantId = restaurantId;
		}
	 
		public String getRestaurantName() {
			return restaurantName;
		}
	 
		public void setRestaurantName(String restaurantName) {
			this.restaurantName = restaurantName;
		}

		@Override
		public String toString() {
			return "Restaurant [restaurantId=" + restaurantId + ", restaurantName=" + restaurantName + "]";
		}
		
		
	}
