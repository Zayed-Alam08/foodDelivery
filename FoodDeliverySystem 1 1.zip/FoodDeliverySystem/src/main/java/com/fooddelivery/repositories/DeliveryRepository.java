package com.fooddelivery.repositories;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.fooddelivery.models.Delivery;

@Repository
public interface DeliveryRepository extends JpaRepository<Delivery, Integer> {

	}

