package com.fooddelivery.repositories;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
 
import com.fooddelivery.models.Member;
public interface MemberRepository extends JpaRepository<Member, Integer> {

		Optional<Member> findByEmailAndPassword(String email, String password);


	}
	 

