package com.fooddelivery.repositories;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.fooddelivery.models.Menu;
import com.fooddelivery.models.Restaurant;
public interface MenuRepository extends JpaRepository<Menu, Integer>{
	
	List<Menu> findByRestaurant(Restaurant restaurant);


}
