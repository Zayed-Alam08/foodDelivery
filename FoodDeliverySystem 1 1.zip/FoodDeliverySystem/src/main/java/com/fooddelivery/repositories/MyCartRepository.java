package com.fooddelivery.repositories;
 
import org.springframework.data.jpa.repository.JpaRepository;

import org.springframework.data.jpa.repository.Modifying;

import org.springframework.data.jpa.repository.Query;

import org.springframework.stereotype.Repository;
 
import com.fooddelivery.models.MyCart;
 
import jakarta.transaction.Transactional;
 
 
@Repository

public interface MyCartRepository extends JpaRepository<MyCart, Integer> {
 
	@Modifying
	@Transactional
	@Query("Update MyCart c SET c.quantity=:quantity where c.itemId=:itemId")
	void changeQuantity(int itemId, int quantity);
 
//	@Modifying

//	@Transactional

//	@Query("UPDATE Cart c SET c.orderId = :orderId WHERE c.orderId = '0'")

//	void updateOrderIdWhereZero(@Param("orderId") String orderId);

}
 