package com.fooddelivery.repositories;
 
 
import org.springframework.data.jpa.repository.JpaRepository;

import org.springframework.stereotype.Repository;

import com.fooddelivery.models.Order;
  
@Repository

public interface OrderRepository extends JpaRepository<Order, String> {

}

 