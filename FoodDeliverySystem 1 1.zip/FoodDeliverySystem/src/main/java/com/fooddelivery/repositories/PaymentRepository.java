package com.fooddelivery.repositories;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.fooddelivery.models.Payment;

@Repository
public interface PaymentRepository extends JpaRepository<Payment,String> {

	Optional<Payment> findByTransactionId(String transactionId);

}
