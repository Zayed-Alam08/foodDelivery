package com.fooddelivery.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.fooddelivery.models.Restaurant;
public interface RestaurantRepository extends JpaRepository<Restaurant, Integer>{

}
