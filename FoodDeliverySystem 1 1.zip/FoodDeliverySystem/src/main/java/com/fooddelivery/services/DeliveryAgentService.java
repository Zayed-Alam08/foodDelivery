package com.fooddelivery.services;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fooddelivery.models.DeliveryAgent;
import com.fooddelivery.repositories.DeliveryAgentRepository;

@Service
public class DeliveryAgentService {
		@Autowired
	    private DeliveryAgentRepository agentRepo;

	    public List<DeliveryAgent> getAllAgents() {
	        return agentRepo.findAll();
	    }

	    public DeliveryAgent getAgentById(int id) {
	        return agentRepo.findById(id).orElseThrow(() -> new RuntimeException("Agent with id " + id + 
	        		" do not exists"));
	    }

	    public DeliveryAgent saveAgent(DeliveryAgent agent) {
	        return agentRepo.save(agent);
	    }
	}


