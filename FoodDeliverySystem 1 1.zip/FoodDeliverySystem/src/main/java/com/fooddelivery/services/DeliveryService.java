package com.fooddelivery.services;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fooddelivery.models.Delivery;
import com.fooddelivery.models.DeliveryAgent;
import com.fooddelivery.repositories.DeliveryAgentRepository;
import com.fooddelivery.repositories.DeliveryRepository;

@Service
public class DeliveryService {
		@Autowired
		private DeliveryRepository deliveryRepo;
		
		@Autowired
		private DeliveryAgentRepository agentRepo;
		
		
		public Delivery createDelivery(Delivery delivery) {
			return deliveryRepo.save(delivery);
		}
		
		
		public Delivery assignAgent(int deliveryId, int agentId) {
		    Delivery delivery= deliveryRepo.findById(deliveryId).orElse(null);
		    DeliveryAgent agent= agentRepo.findById(agentId).orElse(null);
		    if(delivery != null && agent != null) {
		    	delivery.setAgent(agent);
		    	delivery.setDeliverystatus("In Progress");
		    	return deliveryRepo.save(delivery);
		    }
		    return null;
		}
		
		
		public Delivery updateStatus(int deliveryId, String status) {
		   Delivery delivery= deliveryRepo.findById(deliveryId).orElse(null);
		    if(delivery != null) {
		        delivery.setDeliverystatus(status);
		        return deliveryRepo.save(delivery);
		    }
		    return null;
		}
		
		
		public Delivery getDeliveryById(int deliveryid) {
		    return deliveryRepo.findById(deliveryid).orElse(null);
		}
	}


