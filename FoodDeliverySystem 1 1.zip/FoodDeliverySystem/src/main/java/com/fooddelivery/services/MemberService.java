package com.fooddelivery.services;


import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import com.fooddelivery.dao.MemberDAO;

import com.fooddelivery.models.Member;

@Service

public class MemberService {
		@Autowired

		MemberDAO memberDao;

		public String insertMember(Member obj) {

			memberDao.insertMember(obj);

			return "Inserted Successfully";

		}
	 
		public String validateUserByEmail(String email, String password) {

		    Optional<Member> memberOpt = memberDao.findByEmailAndPassword(email, password);

//		    Member memberObj = memberOpt.get();

//		    

//		    System.out.println("Member object : "+memberObj);

		    if (memberOpt.isPresent()) {

		        return "Valid User";

		    } else {

		        return "Invalid User";

		    }

		}
	 
	}
