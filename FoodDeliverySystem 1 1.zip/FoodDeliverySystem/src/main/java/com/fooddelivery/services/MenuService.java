package com.fooddelivery.services;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fooddelivery.models.Menu;
import com.fooddelivery.models.Restaurant;
import com.fooddelivery.repositories.MenuRepository;
import com.fooddelivery.repositories.RestaurantRepository;

@Service
public class MenuService {

		@Autowired
		MenuRepository menuRepo;
		
		@Autowired
		RestaurantRepository restaurantRepo;
		
		//Add menu
		public Menu addMenu(int restaurantId, Menu menu) {
			//menu.setRestaurantId(restaurantId);
			Restaurant restaurant = restaurantRepo.findById(restaurantId).orElse(null);
			if(restaurant != null) {
				menu.setRestaurant(restaurant);
		        return menuRepo.save(menu);
			}
			return null;
		}
		
		//Update menu
		public Menu updateMenu(int restaurantId, int itemId, Menu menu) {
			Menu existingMenu = menuRepo.findById(itemId).orElse(null);
			
			if(existingMenu != null && existingMenu.getRestaurant().getRestaurantId()==(restaurantId)) {
				existingMenu.setItemName(menu.getItemName());
				existingMenu.setPrice(menu.getPrice());
				return menuRepo.save(existingMenu);
	 
			}
			return null;
			
		}
		
		//Delete menu
		public String deleteMenu(int itemId) {
			if(menuRepo.existsById(itemId)) {
				menuRepo.deleteById(itemId);
				return "Menu item deleted successfully";
			}
			else {
				return "Menu item does not exists";
			}
		}
		
		//Get the list of all the menu from the selected restaurant
		public List<Menu> getAllMenu(){
			return menuRepo.findAll();
		}
	 
	}


