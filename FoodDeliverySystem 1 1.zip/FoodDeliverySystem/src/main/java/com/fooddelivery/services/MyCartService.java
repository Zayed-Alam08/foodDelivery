package com.fooddelivery.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fooddelivery.models.MyCart;
import com.fooddelivery.repositories.MyCartRepository;
@Service

public class MyCartService {
	
		@Autowired
		private MyCartRepository mycartRepo;

		public MyCart insertItem(MyCart mycartObj) {
			return mycartRepo.save(mycartObj);
		}
		
		public void deleteItem(int itemId){
			mycartRepo.deleteById(itemId);
		}
		
		public List<MyCart> getMyCartItem(){
			return mycartRepo.findAll();
		}
		
		public void changeQuantity(int itemId,int quantity){
			mycartRepo.changeQuantity(itemId,quantity);
		}
	}

