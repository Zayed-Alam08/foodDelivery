package com.fooddelivery.services;
 
import java.time.LocalDateTime;

import java.util.List;
 
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;
 
import com.fooddelivery.dao.OrderDAO;

import com.fooddelivery.models.Order;
 
@Service

public class OrderService {
 
@Autowired

OrderDAO orDAO;
 
public Order save(Order orderObj) {

	 orderObj.setOrderId("OR" + System.currentTimeMillis());

	 orderObj.setOrderStatus("Pending");

	 orderObj.setOrderDate(LocalDateTime.now());

     return orDAO.save(orderObj); 

}
 
public List<Order> getAllItems() {

     return orDAO.getAllItems(); 

}
 
}
 