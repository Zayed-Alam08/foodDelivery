package com.fooddelivery.services;
import com.fooddelivery.models.Payment;
public interface PaymentService {
			Payment processPayment(Payment payment);
			Payment getPaymentStatus(String transactionId);
			Payment refundPayment(String transactionId);
			String sendConfirmation(String transactionId);
		}

