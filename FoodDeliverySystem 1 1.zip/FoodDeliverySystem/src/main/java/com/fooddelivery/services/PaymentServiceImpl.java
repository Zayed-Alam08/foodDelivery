package com.fooddelivery.services;
import java.time.LocalDateTime;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fooddelivery.models.Payment;
import com.fooddelivery.repositories.PaymentRepository;

@Service
public class PaymentServiceImpl implements PaymentService{

		@Autowired
		private PaymentRepository paymentRepository;
		
		@Override
		public Payment processPayment(Payment payment) {
			payment.setTransactionId("TXN"+System.currentTimeMillis()+payment.getUserId());
			payment.setPaymentstatus("SUCCESS");
			payment.setTimestamp(LocalDateTime.now());
			return paymentRepository.save(payment);
		}
		
		@Override
		public Payment getPaymentStatus(String transactionId) {
			return paymentRepository.findByTransactionId(transactionId)
					.orElseThrow(()->new RuntimeException("Transaction not Found"));
			
		}
		
		@Override
		public Payment refundPayment(String transactionId) {
			Payment payment=getPaymentStatus(transactionId);
			payment.setPaymentstatus("REFUNDED");
			return paymentRepository.save(payment);
		}
		
		@Override
		public String sendConfirmation(String transactionId) {
			Payment payment=getPaymentStatus(transactionId);
			return "Confirmation sent for transaction: "+payment.getTransactionId();
		}
	}


