package com.fooddelivery.services;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fooddelivery.models.Restaurant;
import com.fooddelivery.repositories.RestaurantRepository;

@Service
public class RestaurantService {
		@Autowired
		RestaurantRepository restaurantRepo;
		
		//Get the list of all restaurants
			public List<Restaurant> getAllRestaurants(){
				return restaurantRepo.findAll();
			}
	}


