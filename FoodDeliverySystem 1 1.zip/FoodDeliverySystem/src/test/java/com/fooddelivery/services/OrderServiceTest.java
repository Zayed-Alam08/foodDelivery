//package com.fooddelivery.services;
//
//import static org.mockito.Mockito.*;
//import static org.junit.jupiter.api.Assertions.*;
//
//import java.util.Arrays;
//import java.util.List;
//
//import com.fooddelivery.dao.OrderDAO;
//import com.fooddelivery.models.Order;
//
//import org.junit.jupiter.api.BeforeEach;
//import org.junit.jupiter.api.Test;
//import org.junit.jupiter.api.extension.ExtendWith;
//
//import org.mockito.InjectMocks;
//import org.mockito.Mock;
//import org.mockito.junit.jupiter.MockitoExtension;
//
//@ExtendWith(MockitoExtension.class)
//public class OrderServiceTest {
//
//    @Mock
//    private OrderDAO orderDAO;
//
//    @InjectMocks
//    private OrderService orderService;
//
//    private Order sampleOrder;
//
////    @BeforeEach
////    public void setUp() {
////        sampleOrder = new Order(1, 101, "Placed", 250.0, 5);
////    }
//    
//    @Test
//    public void SaveOrder() {
//        when(orderDAO.save(sampleOrder)).thenReturn("Order Items inserted in the db successfully");
//
//        String result = orderService.save(sampleOrder);
//        assertEquals("Order Items inserted in the db successfully", result);
//    }
//
//    @Test
//    public void testGetAllItems() {
//        List<Order> orders = Arrays.asList(sampleOrder);
//        when(orderDAO.getAllItems()).thenReturn(orders);
//
//        List<Order> result = orderService.getAllItems();
//        assertEquals(1, result.size());
//        assertEquals(101, result.get(0).getCustomerId());
//    }
//}
